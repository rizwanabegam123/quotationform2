<?php
$conn=new mysqli("localhost","root","","conv");

if(isset($_POST['submit'])&&($_POST['phone']))
{
	$id=0;
	$name=$_POST['name'];
	$email=$_POST['email'];
	$phone=$_POST['phone'];
	$Websitetype=$_POST['Websitetype'];
	$WebpageRequired=$_POST['WebpageRequired'];
	$Contentwriting=$_POST['Contentwriting'];
	$WebsiteRequiredin=$_POST['WebsiteRequiredin'];
	$HostingServices=$_POST['HostingServices'];
	$DomainName=$_POST['DomainName'];

	

	$sql="insert into tbl_conv values('$id','$name','$email','$phone','$Websitetype','$WebpageRequired','$Contentwriting','$WebsiteRequiredin','$HostingServices','$DomainName')";
	try{
		if(mysqli_query($conn,$sql)==True)

		echo"<script>
         alert('thanks for contacting us');
         window.location.href='index.html';
         </script>";

	}
	catch(Exception $sql){
	echo"<script>
	alert('your data has not inserted successfully');
	window.location.href='index.html';
	</script>";

  }
}

mysqli_close($conn);

?>

